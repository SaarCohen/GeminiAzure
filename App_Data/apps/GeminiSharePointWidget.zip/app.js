﻿var sharepoint = {
    itemId: 0,
    init: function (id) {

        $('#app-sharepoint #sharepoint-logout').click(function () {
            gemini_ajax.postCall("apps/sharepoint", 'logout', function (response) {
                if (response.success) {
                    sharepoint.refresh();
                }
                else {
                    if (response != '') gemini_popup.toast(response, true);
                }
            });
        });

        $('#app-sharepoint .cs-pills .cs-pill').click(function () {
            $('#app-sharepoint .cs-pills .cs-pill').removeClass('cs-pill-active');
            $(this).addClass('cs-pill-active');
            $('.cs-pill-content').hide();
            $('#' + $(this).attr('data-tab'), '#app-sharepoint').show();
            gemini_ui.chosen('#app-sharepoint #DocumentTypes', null, true);
        });

        $('#attach', '#app-sharepoint').hide();

        sharepoint.itemId = id;
        var timeout;
        $("#btnSerach", "#SharepointDocs").click(function () {
            clearTimeout(timeout);
            if ($("#sharepointSearch", "#SharepointDocs").val() != '') {
                gemini_ui.startBusy2('#app-sharepoint #btnSerach', "#progress-indicator");

                gemini_ajax.postCall("apps/sharepoint", 'search', function (response) {
                    sharepoint.showSearchResults(response);
                    gemini_ui.stopBusy2('#app-sharepoint #btnSerach');
                }, null, $('#SharepointDocs').serialize());
            }
            else {
                //gemini_popup.toast("Enter value in search field", true);
                //$('#app-sharepoint #divSearchResults').html("<div class='no-result'>Enter value in search field</div>")
                $('#app-sharepoint #SharepointDocs').validate().form();
                timeout = setTimeout(function () { $('#app-sharepoint #SharepointDocs #sharepointSearch').removeClass('error') }, 3000)
            }
        });

        $('#app-sharepoint #SharepointDocs #sharepointSearch').blur(function () {
            clearTimeout(timeout);
            $('#app-sharepoint #SharepointDocs #sharepointSearch').removeClass('error');
        });

        $("#btnsharepointDocumentName", "#divCreateDocuments").click(function () {
            if ($.trim($('#sharepointDocumentName', '#divCreateDocuments').val()) == '') {
                gemini_popup.toast('Please Enter New Document Name', true);
            }
            else {
                gemini_ui.startBusy2('#app-sharepoint #btnsharepointDocumentName', "#progress-indicator");
                gemini_ajax.postCall("apps/sharepoint", 'createdocument',
                    function (response) {
                        gemini_ui.stopBusy2('#app-sharepoint #btnsharepointDocumentName', "#progress-indicator");
                        if (response.Result.Data.success) {
                            sharepoint.refresh();
                        }
                        else {
                            if (response.Result.Data.message != '') gemini_popup.toast(response.Result.Data.message, true);
                        }

                    }, function () { gemini_ui.stopBusy2('#app-sharepoint #btnsharepointDocumentName', "#progress-indicator"); }, { itemId: sharepoint.itemId, documentType: $("#DocumentTypes option:selected", "#divCreateDocuments").text(), documentName: $('#sharepointDocumentName', '#divCreateDocuments').val() });
            }
        });

        $('#app-sharepoint #btnUploadDocument').click(function () {
            //gemini_ui.startBusy2('#app-sharepoint #btnUploadDocument', "#progress-indicator");
        });

        $("#upload-form").ajaxForm(options);

        $('#sharepoint-associate .action-button-delete').unbind('click').click(function () {
            var id = $(this).attr('data-id');
            var name = $(this).attr('data-name');
            gemini_commons.translateMessage("[[Delete]] " + name + "?", ['Delete'], function (message) {

                gemini_popup.modalConfirm(message, null,
                    function () {
                        gemini_ajax.postCall("apps/sharepoint", 'removeids',
                            function (response) {
                                if (response.Result.Data.success) {
                                    if ($('#app-sharepoint #sharepoint-associate tbody tr').length == 1)
                                        sharepoint.refresh();
                                    else
                                        $('#app-sharepoint #sharepoint-associate [data-id="' + id + '"]').remove();
                                }
                                else {
                                    if (response.Result.Data.message != '') gemini_popup.toast(response.Result.Data.message, true);
                                }
                            }, null, { ids: id, itemId: sharepoint.itemId });
                    }
                );
            });
        });


        gemini_commons.inputKeyHandler("#app-sharepoint #sharepointSearch",
                        function () {
                            $('#app-sharepoint #btnSerach').click();
                        }
        );

    },
    initAuthentication: function (id) {
        sharepoint.itemId = id;
        $("#sharepoint-login", '#sharepoint-authentication').click(function () {
            gemini_ajax.postCall("apps/sharepoint", 'authenticate',
                function (response) {
                    if (response.Result.Data.success) {
                        sharepoint.refresh();
                    }
                    else {
                        if (response.Result.Data.message != '') gemini_popup.toast(response.Result.Data.message, true);
                    }
                }, null, { username: $('#username', '#sharepoint-authentication').val(), password: $('#password', '#sharepoint-authentication').val() });
        });
    },
    showSearchResults: function (response) {
        $('#divSearchResults').html(response)
        $('#sharepoint-add-existing').unbind('click').click(function () {
            gemini_ui.startBusy2('#app-sharepoint #sharepoint-add-existing', "#progress-indicator");
            var ids = '';
            $('.new-sharepoint-doc:checked', '#sharepoint-new').each(function () {
                ids += $(this).attr('id') + ',';
            });

            gemini_ajax.postCall("apps/sharepoint", 'addids', function () {
                gemini_ui.stopBusy2('#app-sharepoint #sharepoint-add-existing', "#progress-indicator");
                sharepoint.refresh();
            }, function () { gemini_ui.stopBusy2('#app-sharepoint #sharepoint-add-existing', "#progress-indicator"); }, { ids: ids, itemId: sharepoint.itemId });
        });
    },
    refresh: function () {
        gemini_item.getAppControlValue(sharepoint.itemId, '69E77608-1DC7-4E68-B10A-26F1EA82EDDF', 'C48F792C-9B2F-458E-9B71-5B899F8E7478', 'value', '');
    }

}


var options = {
    datype: "json",
    success: function (response) {

        if (response.Result.Data.success) {
            sharepoint.refresh();
        }
        else {
            if (response.Result.Data.message != '') gemini_popup.toast(response.Result.Data.message, true);
        }

    },
    error: function (e, data) {

        alert('Error Uploading the content');

    }// post-submit callback   

};



